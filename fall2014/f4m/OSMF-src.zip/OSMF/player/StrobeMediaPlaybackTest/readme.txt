The StrobeMediaPlaybackTest project contains unit test for the StrobeMediaPlayback project. The project files are Flash Builder 4 compatible.

To execute the unit tests, import the project into Flash Builder, and right click the project in the Package Explorer. Select "Execute FlexUnit tests" from the pop-up menu.