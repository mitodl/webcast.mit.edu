This is a simple player to allow testers to test different VAST creatives in a player.

Steps to test:
Publish VASTNewSample.as
Launch VASTNewSample.html to test the video player

Expected results:
Content video will play.

Additional Instructions:
Change chosenFile and chosenPlacement to other constants to vary creative and placement (make sure they match - e.g. nonlinear ad should be in a nonlinear placement)