#!/bin/bash

if [ -z "$F4FPACKAGER_HOME" ]; then
  export F4FPACKAGER_HOME=`pwd`;
fi

P=":" # The default classpath separator
OS=`uname`
case "$OS" in
  CYGWIN*|MINGW*) # Windows Cygwin or Windows MinGW
  P=";" # Since these are actually Windows, let Java know
  ;;
  Darwin*)

  ;;
  *)
  # Do nothing
  ;;
esac

echo "Running on " $OS

# JAVA options
# You can set JAVA_OPTS to add additional options if you want


export JAVA_OPTS="-Xms256M -Xmx256M"

if [ -z "$F4FPACKAGER_MAINCLASS" ]; then
  export F4FPACKAGER_MAINCLASS=org.flowplayer.f4fpackager.F4FMain
fi

for JAVA in "${JAVA_HOME}/bin/java" "${JAVA_HOME}/Home/bin/java" "/usr/bin/java" "/usr/local/bin/java"
do
  if [ -x "$JAVA" ]
  then
    break
  fi
done

if [ ! -x "$JAVA" ]
then
  echo "Unable to locate Java. Please set JAVA_HOME environment variable."
  exit
fi

export F4FPACKAGER_OPTS=$@
export F4FPACKAGER_CLASSPATH="${F4FPACKAGER_HOME}/lib/*${P}${F4FPACKAGER_HOME}/f4fpackager.jar${P}${CLASSPATH}"

export F4FPACKAGER_CONF_DIR="${F4FPACKAGER_HOME}\conf"

export F4FPACKAGER=/opt/adobe/f4fpackager/f4fpackager

# start F4fPackager
echo "Starting F4fPackager"
exec "$JAVA" $JAVA_OPTS -cp "${F4FPACKAGER_CLASSPATH}" "$F4FPACKAGER_MAINCLASS" $F4FPACKAGER_OPTS
