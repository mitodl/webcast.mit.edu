﻿// Russian lang variables  
tinyMCE.addI18n("ru.streamvideoqt", {
	description : "вставка тегов Stream Video" 
});
