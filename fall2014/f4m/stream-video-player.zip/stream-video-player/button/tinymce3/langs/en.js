// English lang variables  
tinyMCE.addI18n("en.streamvideoqt", {
	description : "Insert Stream Video Tag" 
});
