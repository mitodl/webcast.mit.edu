// Spanish lang variables  
tinyMCE.addI18n("es.streamvideoqt", {
	description : "Insertar etiqueta Stream Video" 
});
